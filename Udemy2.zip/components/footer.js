const footer = () => {
return `
<div style="margin-top: 1rem;
display: flex;
list-style: none;">
    <div style="line-height: 2rem;
  margin-left: 1rem;">
        <li style="color:white" style="color:white">Udemy Bussiness</li>
        <li style="color:white">Teach Acadamy</li>
        <li style="color:white">Get the App</li>
        <li style="color:white">About Us</li>
        <li style="color:white">Contact Us</li>
    </div>
    <div style="line-height: 2rem;
  margin-left: 1rem;margin-left: 10rem;">
        <li style="color:white">Careers</li>
        <li style="color:white">Blog</li>
        <li style="color:white">Help and Support</li>
        <li style="color:white">Affiliate</li>
        <li style="color:white">Investors</li>
    </div>
    <div style="line-height: 2rem;
  margin-left: 1rem;margin-left: 10rem; color:white !important">
        <li style="color:white">Terms</li>
        <li style="color:white">Privvacy Policy</li>
        <li style="color:white">Sitemap</li>
        <li style="color:white">Accessibility Statement</li>
    </div>
    <p style="margin-left: 10rem;" style="margin-top: none;
    margin-left: 34.5rem;
    padding-top: 1.5rem;
    padding: 1rem;
    border-radius: 10%;
    font-size: 1.3rem;">English</p>
</div>

<div style="display: flex;
height: 100px;">
    <img style="width: 5%;
    margin-left: 1rem;
    margin-top: 1rem;" src="https://www.udemy.com/staticx/udemy/images/v7/logo-udemy-inverted.svg">
    <p style=" color:white; position: absolute; bottom:10%; margin-top: 10rem;
    margin-left: 67rem;">© 2021 Udemy, Inc.</p>
</div>
`;
};

export default footer;